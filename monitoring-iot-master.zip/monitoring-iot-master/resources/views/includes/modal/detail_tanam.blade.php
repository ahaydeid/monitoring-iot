<div class="modal fade" id="Dtltanam" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header" id="head">
                
            </div>
            <div class="modal-body mx-3">
                <div class="table-resposive">
                    <table class="table table-striped table-bordered w-100" id="DtlTanamanTanam">
                        <thead>
                            <th>No</th>
                            <th>Tanggal Tanam</th>
                            <th>Tanggal Panen</th>
                            <th>Kuantitas Tanam</th>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
  </div>